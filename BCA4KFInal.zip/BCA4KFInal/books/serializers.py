from rest_framework import serializers
from .models import Books

# how to do seralization
# json <-> pythonobject 
# json 
# {}
# onj = {'name':'virat'}

# for i in json({'name':'virat',age'})
  #  obj[i.k]=i.v
class BooksSerializers(serializers.ModelSerializer):
    class Meta:
        model = Books
        fields = '__all__'
from django.db import models

# Create your models here.
## table Books
class Books(models.Model):
    #id by degault django will provide u id 
    title = models.CharField(max_length=20) # string
    author = models.CharField(max_length=20) # string
    description= models.TextField() # textfiles string (size=undefiend)
    published_date = models.DateField()
    
     # thunder function  
    def __str__(self):
        return "book :"+self.title

